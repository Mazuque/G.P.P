/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projeto_5.ctr;
import java.sql.ResultSet;
import br.com.projeto_5.dto.FuncionarioDTO;
import br.com.projeto_5.dao.FuncionarioDAO;
import br.com.projeto_5.dao.ConexaoDAO;
import br.com.projeto_5.dto.ClienteDTO;
/**
 *
 * @author paulo
 */
public class FuncionarioCTR {
        
    FuncionarioDAO funcionarioDAO = new FuncionarioDAO();
    
    
    public FuncionarioCTR(){
        
    }
    
    public String inserirFuncionario(FuncionarioDTO funcionarioDTO) {
        try{
            //chama o metodo que esta na classe DAO aguardando uma resposta (true ou false)
            if(funcionarioDAO.inserirFuncionario(funcionarioDTO)){
                return "funcionario Cadastro com Sucesso!!";
            }else{
                return "funcionario NÃO cadastrado";
            }
        }//caso tenha algum erro no codigo acima é enviado para uma mensagem no
         //console com o que esta acontecendo
        
        catch (Exception e) {
            System.out.println(e.getMessage());
            return "funcionario NÃO cadastrar!!";
        }
    }//Fecha o método de Inserirfuncionario
    
    public ResultSet consultarFuncionario(FuncionarioDTO funcionarioDTO, int opcao) {
        
        ResultSet rs = null;
        
        rs = funcionarioDAO.consultarFuncionario(funcionarioDTO, opcao);
        
        return rs;
    }//fecha o método consultarfuncionario
    
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }//fecha o método CloseDB

    public String alterarFuncionario(FuncionarioDTO funcionarioDTO) {
        try{
            //chama o metodo que esta na classe DAO aguardando uma resposta (true ou false)
            if(funcionarioDAO.alterarFuncionario(funcionarioDTO)){
                return "funcionario Alterado com Sucesso!!";
            }else{
                return "funcionario NÃO Alterado";
            }
        }//caso tenha algum erro no codigo acima é enviado para uma mensagem no
         //console com o que esta acontecendo
        
        catch (Exception e) {
            System.out.println(e.getMessage());
            return "funcionario NÃO alterador!!";
        }
    }//Fecha o método de alterarfuncionario

    public String excluirFuncionario(FuncionarioDTO funcionarioDTO) {
        try{
            //chama o metodo que esta na classe DAO aguardando uma resposta (true ou false)
            if(funcionarioDAO.excluirFuncionario(funcionarioDTO)){
                return "funcionario Excluído com Sucesso!!";
            }else{
                return "funcionario NÃO Excluido";
            }
        }//caso tenha algum erro no codigo acima é enviado para uma mensagem no
         //console com o que esta acontecendo
        
        catch (Exception e) {
            System.out.println(e.getMessage());
            return "funcionario NÃO deletado!!";
        }
    }//Fecha o método de alterarfuncionario
    
    public String logarFuncionario(FuncionarioDTO funcionarioDTO) {
        return funcionarioDAO.logarFuncionario(funcionarioDTO); // repasse para a DAO
}

    

}

